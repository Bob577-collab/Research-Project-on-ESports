const feedback = document.querySelector(".feedback");
const links = document.querySelectorAll(".links");
const body = document.querySelector("body");
const header = document.querySelector(".header-section");
const divider = document.querySelector(".divider");
const bodySect = document.querySelector(".body-section");
const colors = ["red","green","purple","pink",];

const confettiContainer = document.querySelector(".confetti-container");

const elements = [...links,body,header,divider,bodySect];


letsPlay();

links.forEach((link) =>{
    link.addEventListener("click",function(event){
        event.preventDefault();
        elements.forEach((i) =>{
            i.classList.remove("animate");
            void i.offsetWidth;
            i.classList.add("animate");
        }
        
        )

    setTimeout(() => {
        window.location.href = link.href;
    }, 800);})
    
})

feedback.addEventListener("click", function(){
    window.location.href = "forms.html";
})


function letsPlay(){
    if (!confettiContainer) return;
    
    void confettiContainer.offsetWidth;
    let confettiPiece;
    if(window.location.href.includes("LetsPlay.html")){
        document.querySelector(".navbar").style.zIndex = 1;
        
        for(let i = 0; i<= 100; i++){
            confettiPiece = document.createElement("div");
            confettiPiece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confettiPiece.style.left = `${Math.random() * 1500}px`;
            confettiPiece.classList.add("confetti");
            confettiContainer.appendChild(confettiPiece);
        }
        
          for(let i = 0; i<= 100; i++){
            confettiPiece = document.createElement("div");
            confettiPiece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confettiPiece.style.left = `${Math.random() * 1500}px`;
            confettiPiece.style.top = `${-300 -(Math.random() * 25)}px`;
            confettiPiece.classList.add("confetti");
            confettiContainer.appendChild(confettiPiece);
        }
        setTimeout(() => {
      confettiContainer.innerHTML = "";
       document.querySelector(".navbar").style.zIndex = 500;
    }, 3000);
        
    }
    else{
        return;
    }

}